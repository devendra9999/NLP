ALTER PROC BP_DC_GetProcessingMetrics         
(        
@BatchId UNIQUEIDENTIFIER ,     
@DocumentId UNIQUEIDENTIFIER = NULL    
)        
AS    
--DECLARE @BatchId UNIQUEIDENTIFIER ='8831BDA9-4A15-4F07-A86F-336CB4C2F9BD',     
--@DocumentId UNIQUEIDENTIFIER = NULL   
  
BEGIN    
--DECLARE @BatchId UNIQUEIDENTIFIER = '68801527-3715-4b56-914f-e2f9bdf0a5af'    
    
if object_id('tempdb..#Base') is not null drop table #Base    
if object_id('tempdb..#ExtractedDump') is not null drop table #ExtractedDump    
if object_id('tempdb..#DocumentCaptureData') is not null drop table #DocumentCaptureData    
    
SELECT D.BatchId,D.DocumentIndex,D.IsExceptional,D.Notes,DC.Id,DC.DocumentId,DC.SessionTaskId,      
X.V.query('.') Tables,    
X.V.value('@name', 'varchar(max)') as TableName    
INTO #DocumentCaptureData    
FROM DocumentCaptureData DC    
OUTER APPLY DC.CaptureData.nodes('DOCUMENTS/DOCUMENT/TABLES/TABLE') as X(V)     
INNER JOIN Document D ON D.Id = DC.DocumentId       
INNER JOIN Batch B ON D.BatchId = B.Id AND B.Id = @BatchId AND D.Id = ISNULL(@DocumentId,D.Id)  
       
SELECT ROW_NUMBER() OVER (PARTITION BY SessionTaskId, X.V.value('@name', 'varchar(max)') ORDER BY X.V.value('@region', 'varchar(max)')) rowNum,
B.CreatedOn,B.UpdatedOn, DC.Id,DC.TableName, --ROW_NUMBER() OVER(PARTITION BY DC.TableName,B.BatchId,D.DocumentId ORDER BY    
B.Name BatchName,B.Id BatchId, DT.Name DocumentTypeName,DC. DocumentId,DC.DocumentIndex,    
X.V.value('@region', 'varchar(max)') AS Region,     
X.V.value('@name', 'varchar(max)') as FieldName,     
X.V.value('.', 'nvarchar(max)') as ExtractedValue,    
DC.SessionTaskId,DC.IsExceptional,DC.Notes      
INTO #Base    
FROM  #DocumentCaptureData DC    
OUTER APPLY DC.Tables.nodes('TABLE/ROW/FIELD') as X(V)     
INNER JOIN Batch B ON DC.BatchId = B.Id     
INNER JOIN BatchTypeDocuments BTD ON BTD.BatchTypeId = B.BatchTypeId    
INNER JOIN DocumentType DT ON DT.Id = BTD.DocumentTypeId AND DC.DocumentId = ISNULL(@DocumentId,DC.DocumentId)    
 
  
    
INSERT INTO #Base     
SELECT ROW_NUMBER() OVER (PARTITION BY SessionTaskId, X.V.value('@name', 'varchar(max)') ORDER BY X.V.value('@region', 'varchar(max)')) rowNum,  
B.CreatedOn,B.UpdatedOn, DC.Id,NULL TableName,    
B.Name BatchName,B.Id BatchId, DT.Name DocumentTypeName,DC. DocumentId,D.DocumentIndex,    
X.V.value('@region', 'varchar(max)') AS Region,     
X.V.value('@name', 'varchar(max)') as FieldName,     
X.V.value('.', 'nvarchar(max)') as ExtractedValue,    
DC.SessionTaskId,D.IsExceptional,D.Notes      
FROM  DocumentCaptureData DC    
OUTER APPLY DC.CaptureData.nodes('DOCUMENTS/DOCUMENT/HEADER/FIELD') as X(V)     
INNER JOIN Document D ON D.Id = DC.DocumentId       
INNER JOIN Batch B ON D.BatchId = B.Id AND B.Id = @BatchId  AND D.Id = ISNULL(@DocumentId,D.Id)    
INNER JOIN BatchTypeDocuments BTD ON BTD.BatchTypeId = B.BatchTypeId    
INNER JOIN DocumentType DT ON DT.Id = BTD.DocumentTypeId    

    
    
    
SELECT DISTINCT BF.CreatedOn,BF.UpdatedOn,BF.BatchName,BF.BatchId,BF.DocumentTypeName,BF.DocumentId,BF.TableName,BF.FieldName,    
BF.IsExceptional,BF.Notes,    
BF.ExtractedValue BeforeValue, BF.DocumentIndex,    
CASE WHEN (SELECT COUNT(1) FROM #Base WHERE BatchId = BF.BatchId AND SessionTaskID IS NOT NULL) > 0 THEN 0 ELSE 1 END IsAutoVerified,    
ISNULL(AF.ExtractedValue,BF.ExtractedValue) AfterValue     
INTO #ExtractedDump    
FROM #Base BF    
INNER JOIN #Base AF ON BF.BatchId = AF.BatchId AND BF.DocumentId = AF.DocumentId --AND BF.Region = AF.Region --AND BF.Region <>  -1 AND AF.Region <>  -1    
AND BF.RowNum = AF.RowNum
AND BF.FieldName = AF.FieldName AND ISNULL(BF.SessionTaskId,'00000000-0000-0000-0000-000000000000')  <> AF.SessionTaskId    
AND BF.SessionTaskId IS NULL AND AF.SessionTaskId IS NOT NULL    
ORDER BY BF.DocumentId,BF.FieldName     

IF(SELECT COUNT(1) FROM #ExtractedDump )=0
BEGIN
INSERT INTO #ExtractedDump
SELECT DISTINCT BF.CreatedOn,BF.UpdatedOn,BF.BatchName,BF.BatchId,BF.DocumentTypeName,BF.DocumentId,BF.TableName,BF.FieldName,    
BF.IsExceptional,BF.Notes,    
BF.ExtractedValue BeforeValue, BF.DocumentIndex,    
1 IsAutoVerified,    
BF.ExtractedValue AfterValue      
FROM #Base BF    
ORDER BY BF.DocumentId,BF.FieldName     


END

--SELECT* FROM #ExtractedDump WHERE Documentid = '8AE85837-16DF-44AB-B311-FFE30927D3F5'    
      
SELECT 'ManualVerified' VerificationModel,CreatedOn,UpdatedOn,CONVERT(VARCHAR(100),BatchId) BatchId,    
CONVERT(VARCHAR(100),DocumentId)DocumentId, DocumentIndex, DocumentTypeName, TableName,FieldName,BeforeValue,AfterValue,    
IsExceptional,Notes,    
SUM(CASE WHEN BeforeValue = AfterValue THEN 1.0 ELSE 0.0 END)/COUNT(1)  AccuracyLevel,    
SUM(CASE WHEN (BeforeValue IS NULL  AND AfterValue IS NOT NULL) OR  (BeforeValue = ''  AND AfterValue <> '') THEN 0.0 ELSE 1.0 END)/COUNT(1) ExtractionLevel    
FROM #ExtractedDump     
WHERE IsAutoVerified  = 0    
GROUP BY  CreatedOn,UpdatedOn,CONVERT(VARCHAR(100),BatchId),     
CONVERT(VARCHAR(100),DocumentId),DocumentTypeName,FieldName,BeforeValue,AfterValue,IsExceptional,Notes ,DocumentIndex, TableName    
UNION ALL    
SELECT 'AutoVerified' VerificationModel,CreatedOn,UpdatedOn,CONVERT(VARCHAR(100),BatchId) BatchId, CONVERT(VARCHAR(100),DocumentId)DocumentId    
,DocumentIndex, DocumentTypeName, TableName,FieldName,BeforeValue,AfterValue,    
IsExceptional,Notes,    
SUM(CASE WHEN BeforeValue = AfterValue THEN 1.0 ELSE 0.0 END)/COUNT(1)  AccuracyLevel,    
SUM(CASE WHEN (BeforeValue IS NULL  AND AfterValue IS NOT NULL) OR  (BeforeValue = ''  AND AfterValue <> '') THEN 0.0 ELSE 1.0 END)/COUNT(1) ExtractionLevel    
FROM #ExtractedDump     
WHERE IsAutoVerified  = 1    
GROUP BY  CreatedOn,UpdatedOn,CONVERT(VARCHAR(100),BatchId), CONVERT(VARCHAR(100),DocumentId),DocumentTypeName,FieldName,BeforeValue,AfterValue,IsExceptional,Notes ,DocumentIndex, TableName    
    
    
END